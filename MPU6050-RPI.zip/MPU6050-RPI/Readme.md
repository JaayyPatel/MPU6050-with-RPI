1.getting sensor values of IMU MPU6050 on Rpi terminal
2.Pin interface of MPU6050 with Rpi.
